package com.example.data

import androidx.core.text.HtmlCompat
import com.example.model.MediaResult
import com.example.model.MediaSource
import com.example.model.MediaTypeFilter
import com.example.model.QualityPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

class DownSaveNetworkRepository {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun searchInternetArchive(
        query: String,
        mediaType: MediaTypeFilter,
        quality: QualityPreference
    ): List<MediaResult> = withContext(Dispatchers.IO) {
        val archiveMediaFilter = when (mediaType) {
            MediaTypeFilter.AUDIO -> "audio"
            MediaTypeFilter.VIDEO -> "movies"
            MediaTypeFilter.ALL -> "(audio OR movies)"
        }
        val url = "https://archive.org/advancedsearch.php".toHttpUrl().newBuilder()
            .addQueryParameter("q", "($query) AND mediatype:$archiveMediaFilter")
            .addQueryParameter("fl[]", "identifier,title,creator,year,description")
            .addQueryParameter("rows", "15")
            .addQueryParameter("page", "1")
            .addQueryParameter("output", "json")
            .build()

        val bodyString = executeGet(url.toString(), errorPrefix = "Internet Archive search failed")
        val root = JSONObject(bodyString)
        val docs = root.optJSONObject("response")?.optJSONArray("docs") ?: JSONArray()

        val docList = buildList {
            for (i in 0 until minOf(docs.length(), 12)) {
                add(docs.getJSONObject(i))
            }
        }

        coroutineScope {
            docList.map { doc ->
                async {
                    fetchArchiveItemDetails(doc, mediaType, quality)
                }
            }.awaitAll()
        }
    }

    private fun fetchArchiveItemDetails(
        doc: JSONObject,
        mediaType: MediaTypeFilter,
        quality: QualityPreference
    ): MediaResult {
        val id = doc.optString("identifier", "").trim()
        val title = extractTextField(doc, "title").ifBlank { id }
        val creator = extractTextField(doc, "creator")
        val year = extractTextField(doc, "year")
        val encodedId = encodePathSegment(id)
        val thumbUrl = "https://archive.org/services/img/$encodedId"
        val previewUrl = "https://archive.org/details/$encodedId"

        val baseDetailParts = listOf(creator, year, id).filter { it.isNotBlank() }

        return try {
            val metaString = executeGet(
                "https://archive.org/metadata/$encodedId",
                errorPrefix = "Metadata lookup failed"
            )
            val metaJson = JSONObject(metaString)
            val filesArray = metaJson.optJSONArray("files") ?: JSONArray()

            val audioFiles = mutableListOf<ArchiveFileCandidate>()
            val videoFiles = mutableListOf<ArchiveFileCandidate>()

            for (i in 0 until filesArray.length()) {
                val f = filesArray.optJSONObject(i) ?: continue
                val name = f.optString("name", "")
                if (name.isBlank() || name.contains("__ia_thumb")) continue
                val size = f.optString("size", "0").toLongOrNull() ?: f.optLong("size", 0L)
                if (size <= 0L) continue

                val format = f.optString("format", "").trim()
                val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
                val checkToken = if (format.isNotBlank()) format.lowercase(Locale.US) else ext

                when {
                    ext in AUDIO_EXTENSIONS || checkToken in AUDIO_FORMATS -> {
                        audioFiles.add(ArchiveFileCandidate(name, ext.uppercase(Locale.US), size))
                    }
                    ext in VIDEO_EXTENSIONS || checkToken in VIDEO_FORMATS -> {
                        videoFiles.add(ArchiveFileCandidate(name, ext.uppercase(Locale.US), size))
                    }
                }
            }

            val candidates = when (mediaType) {
                MediaTypeFilter.AUDIO -> audioFiles
                MediaTypeFilter.VIDEO -> videoFiles
                MediaTypeFilter.ALL -> audioFiles.ifEmpty { videoFiles }
            }

            val chosen = pickCandidateByQuality(candidates, quality)
            val downloadUrl = chosen?.let { candidate ->
                val encodedFilePath = candidate.name.split('/').joinToString("/") { encodePathSegment(it) }
                "https://archive.org/download/$encodedId/$encodedFilePath"
            }

            val sizeLabel = chosen?.let { "${it.formatLabel} · ${formatFileSize(it.sizeBytes)}" }
            val detail = (baseDetailParts + listOfNotNull(sizeLabel)).joinToString(" · ")

            MediaResult(
                id = id,
                title = title,
                detail = detail,
                thumbnailUrl = thumbUrl,
                previewUrl = previewUrl,
                downloadUrl = downloadUrl,
                fileFormat = chosen?.formatLabel,
                fileSizeBytes = chosen?.sizeBytes,
                source = MediaSource.ARCHIVE
            )
        } catch (_: Exception) {
            MediaResult(
                id = id,
                title = title,
                detail = baseDetailParts.joinToString(" · "),
                thumbnailUrl = thumbUrl,
                previewUrl = previewUrl,
                downloadUrl = null,
                source = MediaSource.ARCHIVE
            )
        }
    }

    private fun pickCandidateByQuality(
        candidates: List<ArchiveFileCandidate>,
        quality: QualityPreference
    ): ArchiveFileCandidate? {
        if (candidates.isEmpty()) return null
        val sorted = candidates.sortedBy { it.sizeBytes }
        return when (quality) {
            QualityPreference.LOW -> sorted.first()
            QualityPreference.MEDIUM -> sorted[sorted.size / 2]
            QualityPreference.HIGH -> sorted.last()
        }
    }

    suspend fun searchYouTube(
        query: String,
        apiKey: String
    ): List<MediaResult> = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) {
            "Add your YouTube Data API v3 key in the YouTube setup card first."
        }
        val url = "https://www.googleapis.com/youtube/v3/search".toHttpUrl().newBuilder()
            .addQueryParameter("part", "snippet")
            .addQueryParameter("q", query)
            .addQueryParameter("type", "video")
            .addQueryParameter("maxResults", "12")
            .addQueryParameter("regionCode", "PG")
            .addQueryParameter("key", apiKey.trim())
            .build()

        val request = Request.Builder().url(url).get().build()
        val (code, body) = executeRaw(request)
        val json = runCatching { JSONObject(body) }.getOrNull()
        if (code !in 200..299) {
            val apiError = json?.optJSONObject("error")?.optString("message")
            throw IllegalStateException(apiError?.takeIf { it.isNotBlank() } ?: "YouTube API request failed ($code).")
        }

        val items = json?.optJSONArray("items") ?: JSONArray()
        buildList {
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val videoId = item.optJSONObject("id")?.optString("videoId").orEmpty()
                if (videoId.isBlank()) continue
                val snippet = item.optJSONObject("snippet") ?: continue
                val rawTitle = snippet.optString("title", "Untitled video")
                val title = HtmlCompat.fromHtml(rawTitle, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()
                val channel = snippet.optString("channelTitle", "YouTube")
                val published = formatIsoDate(snippet.optString("publishedAt", ""))
                val thumb = snippet.optJSONObject("thumbnails")
                    ?.optJSONObject("medium")
                    ?.optString("url")

                add(
                    MediaResult(
                        id = videoId,
                        title = title,
                        detail = listOf(channel, published).filter { it.isNotBlank() }.joinToString(" · "),
                        thumbnailUrl = thumb,
                        previewUrl = "https://www.youtube.com/watch?v=${encodeQueryParam(videoId)}",
                        downloadUrl = null,
                        embedUrl = "https://www.youtube-nocookie.com/embed/${encodePathSegment(videoId)}",
                        source = MediaSource.YOUTUBE
                    )
                )
            }
        }
    }

    suspend fun searchSoundCloud(
        query: String,
        oauthToken: String
    ): List<MediaResult> = withContext(Dispatchers.IO) {
        if (oauthToken.isBlank()) {
            throw SoundCloudAuthException(
                "SoundCloud search requires an OAuth token from an approved SoundCloud app. You can still open SoundCloud search directly."
            )
        }
        val url = "https://api.soundcloud.com/tracks".toHttpUrl().newBuilder()
            .addQueryParameter("q", query)
            .addQueryParameter("limit", "12")
            .addQueryParameter("access", "playable")
            .build()

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "OAuth ${oauthToken.trim()}")
            .header("Accept", "application/json; charset=utf-8")
            .get()
            .build()

        val (code, body) = executeRaw(request)
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(body).optString("message") }.getOrNull()
            throw SoundCloudAuthException(
                msg?.takeIf { it.isNotBlank() } ?: "SoundCloud API request failed ($code)."
            )
        }

        val trimmed = body.trim()
        val array = if (trimmed.startsWith("[")) {
            JSONArray(trimmed)
        } else {
            JSONObject(trimmed).optJSONArray("collection") ?: JSONArray()
        }

        buildList {
            for (i in 0 until array.length()) {
                val track = array.optJSONObject(i) ?: continue
                val id = track.optLong("id", i.toLong()).toString()
                val title = track.optString("title", "Untitled track")
                val username = track.optJSONObject("user")?.optString("username").orEmpty().ifBlank { "SoundCloud" }
                val duration = formatDurationMs(track.optLong("duration", 0L))
                val thumb = track.optString("artwork_url", "").takeIf { it.isNotBlank() && it != "null" }
                val permalink = track.optString("permalink_url", "").takeIf { it.isNotBlank() && it != "null" }
                val downloadable = track.optBoolean("downloadable", false)
                val downloadUrl = if (downloadable) {
                    track.optString("download_url", "").takeIf { it.isNotBlank() && it != "null" }
                } else {
                    null
                }

                add(
                    MediaResult(
                        id = id,
                        title = title,
                        detail = listOf(username, duration).filter { it.isNotBlank() }.joinToString(" · "),
                        thumbnailUrl = thumb,
                        previewUrl = permalink,
                        downloadUrl = downloadUrl,
                        source = MediaSource.SOUNDCLOUD
                    )
                )
            }
        }
    }

    private fun executeGet(url: String, errorPrefix: String): String {
        val request = Request.Builder().url(url).get().build()
        val (code, body) = executeRaw(request)
        if (code !in 200..299) {
            throw IllegalStateException("$errorPrefix ($code).")
        }
        return body
    }

    private fun executeRaw(request: Request): Pair<Int, String> {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            return response.code to body
        }
    }

    private fun extractTextField(json: JSONObject, key: String): String {
        val value = json.opt(key) ?: return ""
        return when (value) {
            is JSONArray -> (0 until value.length())
                .mapNotNull { value.optString(it).takeIf { s -> s.isNotBlank() } }
                .joinToString(", ")
            else -> value.toString().takeIf { it != "null" }.orEmpty()
        }
    }

    private fun formatDurationMs(ms: Long): String {
        if (ms <= 0L) return ""
        val totalSeconds = ms / 1000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return "%d:%02d".format(Locale.US, minutes, seconds)
    }

    private fun formatIsoDate(iso: String): String {
        if (iso.isBlank()) return ""
        return runCatching {
            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            val parsed = parser.parse(iso) ?: return ""
            SimpleDateFormat("MMM d, yyyy", Locale.US).format(parsed)
        }.getOrDefault(iso.take(10))
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024.0)
    }

    private fun encodePathSegment(segment: String): String =
        URLEncoder.encode(segment, "UTF-8").replace("+", "%20")

    private fun encodeQueryParam(value: String): String =
        URLEncoder.encode(value, "UTF-8")

    private data class ArchiveFileCandidate(
        val name: String,
        val formatLabel: String,
        val sizeBytes: Long
    )

    class SoundCloudAuthException(message: String) : IllegalStateException(message)

    companion object {
        private val AUDIO_EXTENSIONS = setOf("mp3", "ogg", "flac", "wav", "m4a", "aac")
        private val AUDIO_FORMATS = setOf(
            "mp3", "vbr mp3", "128kbps mp3", "64kbps mp3", "ogg vorbis",
            "ogg", "flac", "wave", "wav", "m4a", "aac"
        )
        private val VIDEO_EXTENSIONS = setOf("mp4", "ogv", "webm", "mov")
        private val VIDEO_FORMATS = setOf("mpeg4", "h.264", "h264", "mp4", "ogv", "webm", "512kb mpeg4")
    }
}
