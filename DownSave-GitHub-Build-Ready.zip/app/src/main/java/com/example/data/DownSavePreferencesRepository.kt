package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.DownloadHistoryItem
import com.example.model.MediaTypeFilter
import com.example.model.QualityPreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.downSaveDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "downsave_preferences"
)

data class StoredPreferences(
    val youtubeApiKey: String = "",
    val soundCloudToken: String = "",
    val qualityPreference: QualityPreference = QualityPreference.MEDIUM,
    val mediaTypeFilter: MediaTypeFilter = MediaTypeFilter.ALL,
    val downloadHistory: List<DownloadHistoryItem> = emptyList()
)

class DownSavePreferencesRepository(private val context: Context) {

    val preferencesFlow: Flow<StoredPreferences> = context.downSaveDataStore.data.map { prefs ->
        val quality = runCatching {
            QualityPreference.valueOf(prefs[KEY_QUALITY] ?: QualityPreference.MEDIUM.name)
        }.getOrDefault(QualityPreference.MEDIUM)

        val mediaType = runCatching {
            MediaTypeFilter.valueOf(prefs[KEY_MEDIA_TYPE] ?: MediaTypeFilter.ALL.name)
        }.getOrDefault(MediaTypeFilter.ALL)

        StoredPreferences(
            youtubeApiKey = prefs[KEY_YT_API_KEY].orEmpty(),
            soundCloudToken = prefs[KEY_SC_OAUTH_TOKEN].orEmpty(),
            qualityPreference = quality,
            mediaTypeFilter = mediaType,
            downloadHistory = decodeHistory(prefs[KEY_HISTORY_JSON].orEmpty())
        )
    }

    suspend fun setYoutubeApiKey(key: String) {
        context.downSaveDataStore.edit { prefs ->
            if (key.isBlank()) prefs.remove(KEY_YT_API_KEY) else prefs[KEY_YT_API_KEY] = key.trim()
        }
    }

    suspend fun setSoundCloudToken(token: String) {
        context.downSaveDataStore.edit { prefs ->
            if (token.isBlank()) prefs.remove(KEY_SC_OAUTH_TOKEN) else prefs[KEY_SC_OAUTH_TOKEN] = token.trim()
        }
    }

    suspend fun setQualityPreference(quality: QualityPreference) {
        context.downSaveDataStore.edit { prefs ->
            prefs[KEY_QUALITY] = quality.name
        }
    }

    suspend fun setMediaTypeFilter(filter: MediaTypeFilter) {
        context.downSaveDataStore.edit { prefs ->
            prefs[KEY_MEDIA_TYPE] = filter.name
        }
    }

    suspend fun recordDownload(item: DownloadHistoryItem) {
        context.downSaveDataStore.edit { prefs ->
            val existing = decodeHistory(prefs[KEY_HISTORY_JSON].orEmpty())
            val updated = (listOf(item) + existing).take(30)
            prefs[KEY_HISTORY_JSON] = encodeHistory(updated)
        }
    }

    suspend fun clearHistory() {
        context.downSaveDataStore.edit { prefs ->
            prefs.remove(KEY_HISTORY_JSON)
        }
    }

    private fun decodeHistory(jsonString: String): List<DownloadHistoryItem> {
        if (jsonString.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(jsonString)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    add(
                        DownloadHistoryItem(
                            id = obj.optString("id", i.toString()),
                            title = obj.optString("title", "Media file"),
                            url = obj.optString("url", ""),
                            sourceLabel = obj.optString("sourceLabel", "Direct"),
                            timestampMillis = obj.optLong("timestampMillis", 0L)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun encodeHistory(items: List<DownloadHistoryItem>): String {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("url", item.url)
                    put("sourceLabel", item.sourceLabel)
                    put("timestampMillis", item.timestampMillis)
                }
            )
        }
        return array.toString()
    }

    companion object {
        private val KEY_YT_API_KEY = stringPreferencesKey("yt_api_key")
        private val KEY_SC_OAUTH_TOKEN = stringPreferencesKey("sc_oauth_token")
        private val KEY_QUALITY = stringPreferencesKey("quality_pref")
        private val KEY_MEDIA_TYPE = stringPreferencesKey("media_type_filter")
        private val KEY_HISTORY_JSON = stringPreferencesKey("download_history_json")
    }
}
