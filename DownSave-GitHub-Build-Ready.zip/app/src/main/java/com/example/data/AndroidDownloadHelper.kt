package com.example.data

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import java.util.Locale

object AndroidDownloadHelper {

    val SUPPORTED_DIRECT_EXTENSIONS = setOf("mp3", "mp4", "m4a", "aac", "wav", "ogg", "webm", "mov")

    private val SOCIAL_ALLOWED_HOSTS = setOf(
        "facebook.com",
        "www.facebook.com",
        "m.facebook.com",
        "fb.watch",
        "www.tiktok.com",
        "tiktok.com",
        "vm.tiktok.com"
    )

    sealed interface ValidationResult {
        data class Valid(val uri: Uri, val resolvedFileName: String) : ValidationResult
        data class Invalid(val message: String) : ValidationResult
    }

    fun validateDirectMediaUrl(rawUrl: String, customFileName: String = ""): ValidationResult {
        val trimmed = rawUrl.trim()
        val uri = runCatching { Uri.parse(trimmed) }.getOrNull()
        val scheme = uri?.scheme?.lowercase(Locale.US)
        if (uri == null || (scheme != "http" && scheme != "https") || uri.host.isNullOrBlank()) {
            return ValidationResult.Invalid("Enter a valid HTTP or HTTPS link.")
        }

        val pathExt = uri.lastPathSegment
            ?.substringAfterLast('.', "")
            ?.lowercase(Locale.US)
            .orEmpty()
        if (pathExt !in SUPPORTED_DIRECT_EXTENSIONS) {
            return ValidationResult.Invalid(
                "This does not look like a direct supported media-file URL (.mp3, .mp4, .m4a, .aac, .wav, .ogg, .webm, .mov)."
            )
        }

        val fallbackName = URLUtil.guessFileName(trimmed, null, guessMimeType(pathExt))
        val sanitizedCustom = sanitizeFileName(customFileName)
        val finalName = if (sanitizedCustom.isNotBlank()) {
            if (sanitizedCustom.contains('.')) sanitizedCustom else "$sanitizedCustom.$pathExt"
        } else {
            sanitizeFileName(fallbackName).ifBlank { "downsave_media.$pathExt" }
        }

        return ValidationResult.Valid(uri, finalName)
    }

    fun validateHttpUrl(rawUrl: String): Uri? {
        val trimmed = rawUrl.trim()
        val uri = runCatching { Uri.parse(trimmed) }.getOrNull() ?: return null
        val scheme = uri.scheme?.lowercase(Locale.US)
        return if ((scheme == "http" || scheme == "https") && !uri.host.isNullOrBlank()) uri else null
    }

    fun validateSocialUrl(rawUrl: String): Uri? {
        val uri = validateHttpUrl(rawUrl) ?: return null
        val host = uri.host?.lowercase(Locale.US) ?: return null
        return if (host in SOCIAL_ALLOWED_HOSTS) uri else null
    }

    fun enqueueDownload(
        context: Context,
        url: String,
        suggestedFileName: String? = null
    ): Result<String> {
        return runCatching {
            val uri = Uri.parse(url)
            val ext = uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase(Locale.US).orEmpty()
            val mimeType = guessMimeType(ext)
            val fileName = sanitizeFileName(
                suggestedFileName?.takeIf { it.isNotBlank() }
                    ?: URLUtil.guessFileName(url, null, mimeType)
            ).ifBlank { "downsave_media" }

            val request = DownloadManager.Request(uri).apply {
                if (mimeType != null) setMimeType(mimeType)
                setTitle(fileName)
                setDescription("Downloading with DownSave")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                } else {
                    setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
                }
            }

            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            fileName
        }
    }

    fun openExternalUrl(context: Context, url: String): Boolean {
        val uri = validateHttpUrl(url) ?: return false
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        }
    }

    private fun guessMimeType(ext: String): String? {
        if (ext.isBlank()) return null
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: when (ext) {
                "mp3" -> "audio/mpeg"
                "mp4" -> "video/mp4"
                "m4a" -> "audio/mp4"
                "aac" -> "audio/aac"
                "wav" -> "audio/wav"
                "ogg" -> "audio/ogg"
                "webm" -> "video/webm"
                "mov" -> "video/quicktime"
                else -> null
            }
    }

    private fun sanitizeFileName(name: String): String {
        return name.trim()
            .replace(Regex("[/\\\\:*?\"<>|]"), "_")
            .replace("..", "_")
    }
}
