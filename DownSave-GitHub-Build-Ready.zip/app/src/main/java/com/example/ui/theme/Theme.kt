package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DownSaveLightColorScheme = lightColorScheme(
    primary = AzurePrimary,
    onPrimary = Color.White,
    primaryContainer = SkyContainer,
    onPrimaryContainer = NavyDeep,
    secondary = NavyDeep,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEAF1F7),
    onSecondaryContainer = NavyDeep,
    tertiary = EmeraldSuccess,
    onTertiary = Color.White,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = Color(0xFF0A3D24),
    background = IceBackground,
    onBackground = SlateInk,
    surface = Color.White,
    onSurface = SlateInk,
    surfaceVariant = Color(0xFFE7EDF2),
    onSurfaceVariant = SlateMuted,
    outline = HairlineBorder,
    outlineVariant = Color(0xFFCBD7E2)
)

private val DownSaveDarkColorScheme = darkColorScheme(
    primary = AzureBright,
    onPrimary = Color(0xFF041E33),
    primaryContainer = SkyContainerDark,
    onPrimaryContainer = Color(0xFFD9E9F8),
    secondary = Color(0xFF9AC5EB),
    onSecondary = NavyDeep,
    secondaryContainer = DarkSurfaceElevated,
    onSecondaryContainer = DarkInk,
    tertiary = Color(0xFF5BD496),
    onTertiary = Color(0xFF052E19),
    tertiaryContainer = Color(0xFF103F28),
    onTertiaryContainer = Color(0xFFC1F2D8),
    background = DarkBackground,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = DarkMuted,
    outline = DarkBorder,
    outlineVariant = Color(0xFF324D6B)
)

val DownSaveShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun DownSaveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DownSaveDarkColorScheme else DownSaveLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DownSaveTypography,
        shapes = DownSaveShapes,
        content = content
    )
}
