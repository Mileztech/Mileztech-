package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AndroidDownloadHelper
import com.example.data.DownSaveNetworkRepository
import com.example.data.DownSavePreferencesRepository
import com.example.model.AppTab
import com.example.model.DownloadHistoryItem
import com.example.model.MediaResult
import com.example.model.MediaSource
import com.example.model.MediaTypeFilter
import com.example.model.QualityPreference
import com.example.model.SearchUiState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.util.UUID

data class DownSaveUiState(
    val activeTab: AppTab = AppTab.DISCOVER,
    val selectedSource: MediaSource = MediaSource.ARCHIVE,
    val searchQuery: String = "",
    val searchState: SearchUiState = SearchUiState.Idle,
    val showCredentialEditor: Boolean = false,
    val youtubeKeyInput: String = "",
    val soundCloudTokenInput: String = "",
    val savedYoutubeKey: String = "",
    val savedSoundCloudToken: String = "",
    val qualityPreference: QualityPreference = QualityPreference.MEDIUM,
    val mediaTypeFilter: MediaTypeFilter = MediaTypeFilter.ALL,
    val directUrlInput: String = "",
    val directFileNameInput: String = "",
    val directStatusMessage: String? = null,
    val directStatusIsError: Boolean = false,
    val socialUrlInput: String = "",
    val socialStatusMessage: String? = null,
    val socialStatusIsError: Boolean = false,
    val downloadHistory: List<DownloadHistoryItem> = emptyList(),
    val activeEmbedResult: MediaResult? = null
)

class DownSaveViewModel(application: Application) : AndroidViewModel(application) {

    private val networkRepository = DownSaveNetworkRepository()
    private val prefsRepository = DownSavePreferencesRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(DownSaveUiState())
    val uiState: StateFlow<DownSaveUiState> = _uiState.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    private var didHydrateInputs = false

    init {
        viewModelScope.launch {
            prefsRepository.preferencesFlow.collect { stored ->
                _uiState.update { current ->
                    current.copy(
                        savedYoutubeKey = stored.youtubeApiKey,
                        savedSoundCloudToken = stored.soundCloudToken,
                        youtubeKeyInput = if (!didHydrateInputs) stored.youtubeApiKey else current.youtubeKeyInput,
                        soundCloudTokenInput = if (!didHydrateInputs) stored.soundCloudToken else current.soundCloudTokenInput,
                        qualityPreference = stored.qualityPreference,
                        mediaTypeFilter = stored.mediaTypeFilter,
                        downloadHistory = stored.downloadHistory
                    )
                }
                didHydrateInputs = true
            }
        }
    }

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun selectSource(source: MediaSource) {
        _uiState.update { state ->
            val needsSetup = when (source) {
                MediaSource.YOUTUBE -> state.savedYoutubeKey.isBlank()
                MediaSource.SOUNDCLOUD -> state.savedSoundCloudToken.isBlank()
                MediaSource.ARCHIVE -> false
            }
            state.copy(
                selectedSource = source,
                searchState = SearchUiState.Idle,
                showCredentialEditor = needsSetup
            )
        }
    }

    fun toggleCredentialEditor() {
        _uiState.update { it.copy(showCredentialEditor = !it.showCredentialEditor) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun updateYoutubeKeyInput(value: String) {
        _uiState.update { it.copy(youtubeKeyInput = value) }
    }

    fun saveYoutubeKey() {
        val key = _uiState.value.youtubeKeyInput.trim()
        viewModelScope.launch {
            prefsRepository.setYoutubeApiKey(key)
            _uiState.update { it.copy(showCredentialEditor = key.isBlank()) }
            _snackbarEvents.tryEmit(
                if (key.isNotBlank()) "YouTube API key saved on this device." else "YouTube API key cleared."
            )
        }
    }

    fun clearYoutubeKey() {
        viewModelScope.launch {
            prefsRepository.setYoutubeApiKey("")
            _uiState.update { it.copy(youtubeKeyInput = "") }
            _snackbarEvents.tryEmit("YouTube API key cleared.")
        }
    }

    fun updateSoundCloudTokenInput(value: String) {
        _uiState.update { it.copy(soundCloudTokenInput = value) }
    }

    fun saveSoundCloudToken() {
        val token = _uiState.value.soundCloudTokenInput.trim()
        viewModelScope.launch {
            prefsRepository.setSoundCloudToken(token)
            _uiState.update { it.copy(showCredentialEditor = token.isBlank()) }
            _snackbarEvents.tryEmit(
                if (token.isNotBlank()) "SoundCloud token saved on this device." else "SoundCloud token cleared."
            )
        }
    }

    fun clearSoundCloudToken() {
        viewModelScope.launch {
            prefsRepository.setSoundCloudToken("")
            _uiState.update { it.copy(soundCloudTokenInput = "") }
            _snackbarEvents.tryEmit("SoundCloud token cleared.")
        }
    }

    fun setQualityPreference(quality: QualityPreference) {
        viewModelScope.launch {
            prefsRepository.setQualityPreference(quality)
        }
    }

    fun setMediaTypeFilter(filter: MediaTypeFilter) {
        viewModelScope.launch {
            prefsRepository.setMediaTypeFilter(filter)
        }
    }

    fun performSearch() {
        val state = _uiState.value
        val query = state.searchQuery.trim()
        if (query.isBlank()) {
            _snackbarEvents.tryEmit("Enter a search term first.")
            return
        }

        _uiState.update { it.copy(searchState = SearchUiState.Loading) }

        viewModelScope.launch {
            val source = state.selectedSource
            try {
                val results = when (source) {
                    MediaSource.ARCHIVE -> networkRepository.searchInternetArchive(
                        query = query,
                        mediaType = state.mediaTypeFilter,
                        quality = state.qualityPreference
                    )
                    MediaSource.YOUTUBE -> networkRepository.searchYouTube(
                        query = query,
                        apiKey = state.savedYoutubeKey
                    )
                    MediaSource.SOUNDCLOUD -> networkRepository.searchSoundCloud(
                        query = query,
                        oauthToken = state.savedSoundCloudToken
                    )
                }
                _uiState.update {
                    it.copy(searchState = SearchUiState.Success(results, query, source))
                }
            } catch (e: DownSaveNetworkRepository.SoundCloudAuthException) {
                val encodedQuery = URLEncoder.encode(query, "UTF-8")
                _uiState.update {
                    it.copy(
                        searchState = SearchUiState.Error(
                            message = e.message ?: "SoundCloud search failed.",
                            fallbackUrl = "https://soundcloud.com/search?q=$encodedQuery",
                            fallbackLabel = "Open SoundCloud search"
                        )
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        searchState = SearchUiState.Error(
                            message = e.message ?: "Could not complete search."
                        )
                    )
                }
            }
        }
    }

    fun openEmbedPreview(result: MediaResult) {
        _uiState.update { it.copy(activeEmbedResult = result) }
    }

    fun closeEmbedPreview() {
        _uiState.update { it.copy(activeEmbedResult = null) }
    }

    fun openExternalPreview(url: String) {
        val opened = AndroidDownloadHelper.openExternalUrl(getApplication(), url)
        if (!opened) {
            _snackbarEvents.tryEmit("No browser or app available to open this link.")
        }
    }

    fun downloadResult(result: MediaResult) {
        val url = result.downloadUrl ?: return
        val suggestedName = result.fileFormat?.let { fmt ->
            val cleanTitle = result.title.take(48).replace(Regex("[^A-Za-z0-9._ -]"), "_").trim()
            if (cleanTitle.isNotBlank()) "$cleanTitle.${fmt.lowercase()}" else null
        }

        val enqueueResult = AndroidDownloadHelper.enqueueDownload(
            context = getApplication(),
            url = url,
            suggestedFileName = suggestedName
        )

        enqueueResult.onSuccess { fileName ->
            viewModelScope.launch {
                prefsRepository.recordDownload(
                    DownloadHistoryItem(
                        id = UUID.randomUUID().toString(),
                        title = result.title,
                        url = url,
                        sourceLabel = result.source.label,
                        timestampMillis = System.currentTimeMillis()
                    )
                )
            }
            _snackbarEvents.tryEmit("Download started: $fileName")
        }.onFailure { err ->
            _snackbarEvents.tryEmit("Could not start download: ${err.message ?: "Unknown error"}")
        }
    }

    fun updateDirectUrlInput(value: String) {
        _uiState.update { it.copy(directUrlInput = value, directStatusMessage = null) }
    }

    fun updateDirectFileNameInput(value: String) {
        _uiState.update { it.copy(directFileNameInput = value, directStatusMessage = null) }
    }

    fun downloadDirectUrl() {
        val state = _uiState.value
        when (val validation = AndroidDownloadHelper.validateDirectMediaUrl(
            rawUrl = state.directUrlInput,
            customFileName = state.directFileNameInput
        )) {
            is AndroidDownloadHelper.ValidationResult.Invalid -> {
                _uiState.update {
                    it.copy(
                        directStatusMessage = validation.message,
                        directStatusIsError = true
                    )
                }
            }
            is AndroidDownloadHelper.ValidationResult.Valid -> {
                val url = validation.uri.toString()
                val enqueueResult = AndroidDownloadHelper.enqueueDownload(
                    context = getApplication(),
                    url = url,
                    suggestedFileName = validation.resolvedFileName
                )
                enqueueResult.onSuccess { fileName ->
                    viewModelScope.launch {
                        prefsRepository.recordDownload(
                            DownloadHistoryItem(
                                id = UUID.randomUUID().toString(),
                                title = fileName,
                                url = url,
                                sourceLabel = "Direct link",
                                timestampMillis = System.currentTimeMillis()
                            )
                        )
                    }
                    _uiState.update {
                        it.copy(
                            directStatusMessage = "Download requested via Android DownloadManager ($fileName). Check your notifications.",
                            directStatusIsError = false
                        )
                    }
                    _snackbarEvents.tryEmit("Download started: $fileName")
                }.onFailure { err ->
                    _uiState.update {
                        it.copy(
                            directStatusMessage = "Could not start download: ${err.message}",
                            directStatusIsError = true
                        )
                    }
                }
            }
        }
    }

    fun openDirectUrl() {
        val uri = AndroidDownloadHelper.validateHttpUrl(_uiState.value.directUrlInput)
        if (uri == null) {
            _uiState.update {
                it.copy(
                    directStatusMessage = "Enter a valid HTTP or HTTPS link.",
                    directStatusIsError = true
                )
            }
            return
        }
        val opened = AndroidDownloadHelper.openExternalUrl(getApplication(), uri.toString())
        if (!opened) {
            _uiState.update {
                it.copy(
                    directStatusMessage = "No browser app available to open this URL.",
                    directStatusIsError = true
                )
            }
        }
    }

    fun updateSocialUrlInput(value: String) {
        _uiState.update { it.copy(socialUrlInput = value, socialStatusMessage = null) }
    }

    fun openSocialUrl() {
        val uri = AndroidDownloadHelper.validateSocialUrl(_uiState.value.socialUrlInput)
        if (uri == null) {
            _uiState.update {
                it.copy(
                    socialStatusMessage = "Enter a valid Facebook or TikTok URL (facebook.com, fb.watch, tiktok.com).",
                    socialStatusIsError = true
                )
            }
            return
        }
        val opened = AndroidDownloadHelper.openExternalUrl(getApplication(), uri.toString())
        _uiState.update {
            if (opened) {
                it.copy(
                    socialStatusMessage = "Opened official post on ${uri.host}.",
                    socialStatusIsError = false
                )
            } else {
                it.copy(
                    socialStatusMessage = "No app or browser found to open ${uri.host}.",
                    socialStatusIsError = true
                )
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            prefsRepository.clearHistory()
            _snackbarEvents.tryEmit("Download history cleared.")
        }
    }
}
