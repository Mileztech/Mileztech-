package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.TravelExplore
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.AndroidDownloadHelper
import com.example.model.AppTab
import com.example.model.MediaSource
import com.example.model.MediaTypeFilter
import com.example.model.QualityPreference
import com.example.model.SearchUiState
import java.text.DateFormat
import java.util.Date

@Composable
fun DownSaveApp(
    viewModel: DownSaveViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    state.activeEmbedResult?.let { embedResult ->
        EmbedPreviewDialog(
            result = embedResult,
            onDismiss = viewModel::closeEmbedPreview,
            onOpenExternal = viewModel::openExternalPreview
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    DownSaveBottomBar(
                        activeTab = state.activeTab,
                        onSelectTab = viewModel::selectTab
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    DownSaveNavigationRail(
                        activeTab = state.activeTab,
                        onSelectTab = viewModel::selectTab
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    when (state.activeTab) {
                        AppTab.DISCOVER -> DiscoverScreen(
                            state = state,
                            viewModel = viewModel,
                            modifier = Modifier.widthIn(max = 780.dp)
                        )
                        AppTab.DIRECT_LINKS -> DirectAndSocialScreen(
                            state = state,
                            viewModel = viewModel,
                            modifier = Modifier.widthIn(max = 780.dp)
                        )
                        AppTab.LIBRARY -> LibraryAndSettingsScreen(
                            state = state,
                            viewModel = viewModel,
                            modifier = Modifier.widthIn(max = 780.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DownSaveBottomBar(
    activeTab: AppTab,
    onSelectTab: (AppTab) -> Unit
) {
    NavigationBar(windowInsets = WindowInsets.navigationBars) {
        AppTab.entries.forEach { tab ->
            val selected = tab == activeTab
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = {
                    Icon(
                        imageVector = tabIcon(tab, selected),
                        contentDescription = tab.title
                    )
                },
                label = { Text(tab.title) },
                modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
            )
        }
    }
}

@Composable
private fun DownSaveNavigationRail(
    activeTab: AppTab,
    onSelectTab: (AppTab) -> Unit
) {
    NavigationRail(modifier = Modifier.fillMaxHeight()) {
        Spacer(modifier = Modifier.height(12.dp))
        AppTab.entries.forEach { tab ->
            val selected = tab == activeTab
            NavigationRailItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = {
                    Icon(
                        imageVector = tabIcon(tab, selected),
                        contentDescription = tab.title
                    )
                },
                label = { Text(tab.title) },
                modifier = Modifier.testTag("rail_${tab.name.lowercase()}")
            )
        }
    }
}

private fun tabIcon(tab: AppTab, selected: Boolean) = when (tab) {
    AppTab.DISCOVER -> if (selected) Icons.Rounded.TravelExplore else Icons.Outlined.TravelExplore
    AppTab.DIRECT_LINKS -> if (selected) Icons.Rounded.Link else Icons.Outlined.Link
    AppTab.LIBRARY -> if (selected) Icons.Rounded.History else Icons.Outlined.History
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DiscoverScreen(
    state: DownSaveUiState,
    viewModel: DownSaveViewModel,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val isSearching = state.searchState is SearchUiState.Loading

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            DownSaveHeaderBanner(qualityPreference = state.qualityPreference)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "1. Choose a source",
                            style = MaterialTheme.typography.titleLarge
                        )
                        if (state.selectedSource != MediaSource.ARCHIVE) {
                            TextButton(
                                onClick = viewModel::toggleCredentialEditor,
                                modifier = Modifier.testTag("toggle_credential_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Key,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (state.showCredentialEditor) "Hide key" else "API key")
                            }
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MediaSource.entries.forEach { source ->
                            FilterChip(
                                selected = state.selectedSource == source,
                                onClick = { viewModel.selectSource(source) },
                                label = { Text(source.label) },
                                modifier = Modifier.testTag("source_chip_${source.name.lowercase()}")
                            )
                        }
                    }

                    OutlinedTextField(
                        value = state.searchQuery,
                        onValueChange = viewModel::updateSearchQuery,
                        label = { Text(stringResource(R.string.search_label)) },
                        placeholder = { Text(stringResource(R.string.search_placeholder)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                focusManager.clearFocus()
                                viewModel.performSearch()
                            }
                        ),
                        trailingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = null
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                focusManager.clearFocus()
                                viewModel.performSearch()
                            },
                            enabled = !isSearching,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("search_button")
                        ) {
                            if (isSearching) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.searching_status))
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.search_action))
                            }
                        }
                    }

                    Text(
                        text = when (state.selectedSource) {
                            MediaSource.ARCHIVE -> stringResource(R.string.hint_archive)
                            MediaSource.YOUTUBE -> stringResource(R.string.hint_youtube)
                            MediaSource.SOUNDCLOUD -> stringResource(R.string.hint_soundcloud)
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (state.selectedSource == MediaSource.ARCHIVE) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            MediaTypeFilter.entries.forEach { filter ->
                                FilterChip(
                                    selected = state.mediaTypeFilter == filter,
                                    onClick = { viewModel.setMediaTypeFilter(filter) },
                                    label = { Text(filter.label) },
                                    modifier = Modifier.testTag("mediatype_chip_${filter.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            AnimatedVisibility(
                visible = state.showCredentialEditor && state.selectedSource != MediaSource.ARCHIVE
            ) {
                if (state.selectedSource == MediaSource.YOUTUBE) {
                    SourceCredentialCard(
                        source = MediaSource.YOUTUBE,
                        inputValue = state.youtubeKeyInput,
                        onValueChange = viewModel::updateYoutubeKeyInput,
                        onSave = viewModel::saveYoutubeKey,
                        onClear = viewModel::clearYoutubeKey
                    )
                } else if (state.selectedSource == MediaSource.SOUNDCLOUD) {
                    SourceCredentialCard(
                        source = MediaSource.SOUNDCLOUD,
                        inputValue = state.soundCloudTokenInput,
                        onValueChange = viewModel::updateSoundCloudTokenInput,
                        onSave = viewModel::saveSoundCloudToken,
                        onClear = viewModel::clearSoundCloudToken
                    )
                }
            }
        }

        when (val searchState = state.searchState) {
            is SearchUiState.Idle -> {
                item {
                    EmptyResultsCard(
                        title = "Ready to search",
                        message = stringResource(R.string.results_empty_prompt)
                    )
                }
            }
            is SearchUiState.Loading -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = stringResource(R.string.searching_status),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
            is SearchUiState.Error -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ErrorOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Text(
                                    text = "Search could not complete",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            Text(
                                text = searchState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            if (searchState.fallbackUrl != null && searchState.fallbackLabel != null) {
                                OutlinedButton(
                                    onClick = { viewModel.openExternalPreview(searchState.fallbackUrl) }
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(searchState.fallbackLabel)
                                }
                            }
                        }
                    }
                }
            }
            is SearchUiState.Success -> {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Search results",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "${searchState.items.size} result${if (searchState.items.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (searchState.items.isEmpty()) {
                    item {
                        EmptyResultsCard(
                            title = "No matches found",
                            message = stringResource(R.string.results_empty_none)
                        )
                    }
                } else {
                    items(searchState.items, key = { "${it.source.name}_${it.id}" }) { result ->
                        MediaResultCard(
                            item = result,
                            onPreviewExternal = { result.previewUrl?.let(viewModel::openExternalPreview) },
                            onPreviewEmbed = { viewModel.openEmbedPreview(result) },
                            onDownload = { viewModel.downloadResult(result) }
                        )
                    }
                }
            }
        }

        item {
            ComplianceNoticeCard()
        }

        item {
            Text(
                text = stringResource(R.string.footer_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun EmptyResultsCard(
    title: String,
    message: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.TravelExplore,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DirectAndSocialScreen(
    state: DownSaveUiState,
    viewModel: DownSaveViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CloudDownload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.direct_title),
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    Text(
                        text = stringResource(R.string.direct_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AndroidDownloadHelper.SUPPORTED_DIRECT_EXTENSIONS.forEach { ext ->
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = ".${ext.uppercase()}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = state.directUrlInput,
                        onValueChange = viewModel::updateDirectUrlInput,
                        label = { Text(stringResource(R.string.direct_url_label)) },
                        placeholder = { Text(stringResource(R.string.direct_url_hint)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("direct_url_input")
                    )

                    OutlinedTextField(
                        value = state.directFileNameInput,
                        onValueChange = viewModel::updateDirectFileNameInput,
                        label = { Text(stringResource(R.string.direct_name_label)) },
                        placeholder = { Text(stringResource(R.string.direct_name_hint)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("direct_filename_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = viewModel::downloadDirectUrl,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("direct_download_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudDownload,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.direct_download_btn))
                        }

                        OutlinedButton(
                            onClick = viewModel::openDirectUrl,
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("direct_open_button")
                        ) {
                            Text(stringResource(R.string.open_link_btn))
                        }
                    }

                    state.directStatusMessage?.let { msg ->
                        StatusBanner(text = msg, isError = state.directStatusIsError)
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Public,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.social_title),
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    Text(
                        text = stringResource(R.string.social_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = state.socialUrlInput,
                        onValueChange = viewModel::updateSocialUrlInput,
                        label = { Text(stringResource(R.string.social_url_label)) },
                        placeholder = { Text(stringResource(R.string.social_url_hint)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("social_url_input")
                    )

                    Button(
                        onClick = viewModel::openSocialUrl,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("open_social_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.open_official_btn))
                    }

                    state.socialStatusMessage?.let { msg ->
                        StatusBanner(text = msg, isError = state.socialStatusIsError)
                    }
                }
            }
        }

        item {
            ComplianceNoticeCard()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LibraryAndSettingsScreen(
    state: DownSaveUiState,
    viewModel: DownSaveViewModel,
    modifier: Modifier = Modifier
) {
    val dateFormatter = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = stringResource(R.string.prefs_title),
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        text = stringResource(R.string.quality_label),
                        style = MaterialTheme.typography.titleSmall
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QualityPreference.entries.forEach { quality ->
                            FilterChip(
                                selected = state.qualityPreference == quality,
                                onClick = { viewModel.setQualityPreference(quality) },
                                label = { Text(quality.label) },
                                modifier = Modifier.testTag("quality_chip_${quality.name.lowercase()}")
                            )
                        }
                    }

                    Text(
                        text = state.qualityPreference.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)

                    Text(
                        text = stringResource(R.string.media_type_label),
                        style = MaterialTheme.typography.titleSmall
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MediaTypeFilter.entries.forEach { filter ->
                            FilterChip(
                                selected = state.mediaTypeFilter == filter,
                                onClick = { viewModel.setMediaTypeFilter(filter) },
                                label = { Text(filter.label) },
                                modifier = Modifier.testTag("settings_mediatype_${filter.name.lowercase()}")
                            )
                        }
                    }

                    Text(
                        text = stringResource(R.string.prefs_note),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            SourceCredentialCard(
                source = MediaSource.YOUTUBE,
                inputValue = state.youtubeKeyInput,
                onValueChange = viewModel::updateYoutubeKeyInput,
                onSave = viewModel::saveYoutubeKey,
                onClear = viewModel::clearYoutubeKey
            )
        }

        item {
            SourceCredentialCard(
                source = MediaSource.SOUNDCLOUD,
                inputValue = state.soundCloudTokenInput,
                onValueChange = viewModel::updateSoundCloudTokenInput,
                onSave = viewModel::saveSoundCloudToken,
                onClear = viewModel::clearSoundCloudToken
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.history_title),
                            style = MaterialTheme.typography.titleLarge
                        )
                        if (state.downloadHistory.isNotEmpty()) {
                            OutlinedButton(
                                onClick = viewModel::clearHistory,
                                modifier = Modifier.testTag("clear_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.history_clear))
                            }
                        }
                    }

                    if (state.downloadHistory.isEmpty()) {
                        Text(
                            text = stringResource(R.string.history_empty),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        state.downloadHistory.forEachIndexed { index, item ->
                            if (index > 0) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${item.sourceLabel} · ${dateFormatter.format(Date(item.timestampMillis))}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.openExternalPreview(item.url) }
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                        contentDescription = "Open download URL"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            ComplianceNoticeCard()
        }

        item {
            Text(
                text = stringResource(R.string.footer_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun StatusBanner(
    text: String,
    isError: Boolean
) {
    val container = if (isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.tertiaryContainer
    val content = if (isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.small,
        color = container
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isError) Icons.Rounded.ErrorOutline else Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint = content,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = content
            )
        }
    }
}
