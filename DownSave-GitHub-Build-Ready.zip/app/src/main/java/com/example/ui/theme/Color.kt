package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DownSave Mileztech Brand Palette
val NavyDeep = Color(0xFF102B46)
val NavyContainer = Color(0xFF1A3E63)
val AzurePrimary = Color(0xFF1769AA)
val AzureBright = Color(0xFF4BA3E3)
val SkyContainer = Color(0xFFEAF4FC)
val SkyContainerDark = Color(0xFF133350)

val IceBackground = Color(0xFFF4F7FA)
val SlateInk = Color(0xFF172536)
val SlateMuted = Color(0xFF5D6E82)
val HairlineBorder = Color(0xFFDCE5ED)

val DarkBackground = Color(0xFF0B1520)
val DarkSurface = Color(0xFF112030)
val DarkSurfaceElevated = Color(0xFF172B40)
val DarkBorder = Color(0xFF253C56)
val DarkInk = Color(0xFFEAF1F8)
val DarkMuted = Color(0xFF9FB2C7)

val EmeraldSuccess = Color(0xFF16784A)
val EmeraldContainer = Color(0xFFE4F5EC)
val AmberNoticeBg = Color(0xFFFFF7DF)
val AmberNoticeBorder = Color(0xFFF0D88C)
val AmberNoticeText = Color(0xFF6A4D00)
val AmberNoticeDarkBg = Color(0xFF2C230B)
val AmberNoticeDarkBorder = Color(0xFF665018)
val AmberNoticeDarkText = Color(0xFFF5D88A)
