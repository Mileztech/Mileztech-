package com.example.model

enum class AppTab(val title: String) {
    DISCOVER("Discover"),
    DIRECT_LINKS("Direct & Links"),
    LIBRARY("Library")
}

enum class MediaSource(val label: String, val shortLabel: String) {
    ARCHIVE("Internet Archive", "Archive"),
    YOUTUBE("YouTube", "YouTube"),
    SOUNDCLOUD("SoundCloud", "SoundCloud")
}

enum class QualityPreference(val label: String, val subtitle: String) {
    LOW("Low data", "Smallest files when available"),
    MEDIUM("Standard", "Balanced size and clarity"),
    HIGH("High quality", "Best source file available")
}

enum class MediaTypeFilter(val label: String) {
    ALL("Audio & video"),
    AUDIO("Audio only"),
    VIDEO("Video only")
}

data class MediaResult(
    val id: String,
    val title: String,
    val detail: String,
    val thumbnailUrl: String?,
    val previewUrl: String?,
    val downloadUrl: String?,
    val embedUrl: String? = null,
    val fileFormat: String? = null,
    val fileSizeBytes: Long? = null,
    val source: MediaSource
)

data class DownloadHistoryItem(
    val id: String,
    val title: String,
    val url: String,
    val sourceLabel: String,
    val timestampMillis: Long
)

sealed interface SearchUiState {
    data object Idle : SearchUiState
    data object Loading : SearchUiState
    data class Success(val items: List<MediaResult>, val query: String, val source: MediaSource) : SearchUiState
    data class Error(
        val message: String,
        val fallbackUrl: String? = null,
        val fallbackLabel: String? = null
    ) : SearchUiState
}
