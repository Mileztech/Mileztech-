package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AndroidDownloadHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read DownSave app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DownSave", appName)
    }

    @Test
    fun `validate direct media URL accepts supported formats`() {
        val valid = AndroidDownloadHelper.validateDirectMediaUrl(
            "https://example.com/tracks/sample.mp3",
            "MyTrack"
        )
        assertTrue(valid is AndroidDownloadHelper.ValidationResult.Valid)
        val result = valid as AndroidDownloadHelper.ValidationResult.Valid
        assertEquals("MyTrack.mp3", result.resolvedFileName)
    }

    @Test
    fun `validate direct media URL rejects unsupported or non-http URLs`() {
        val invalidExt = AndroidDownloadHelper.validateDirectMediaUrl("https://example.com/page.html")
        assertTrue(invalidExt is AndroidDownloadHelper.ValidationResult.Invalid)

        val invalidScheme = AndroidDownloadHelper.validateDirectMediaUrl("ftp://example.com/audio.mp3")
        assertTrue(invalidScheme is AndroidDownloadHelper.ValidationResult.Invalid)
    }

    @Test
    fun `validate social URL allows only official Facebook and TikTok hosts`() {
        assertNotNull(AndroidDownloadHelper.validateSocialUrl("https://www.tiktok.com/@creator/video/123"))
        assertNotNull(AndroidDownloadHelper.validateSocialUrl("https://fb.watch/abc123/"))
        assertNull(AndroidDownloadHelper.validateSocialUrl("https://example.com/tiktok"))
    }
}
