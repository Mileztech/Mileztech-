# DownSave Android — Powered by Mileztech

This is the Android Studio project wrapper for the DownSave HTML prototype.

## Current functionality
- Android launcher app with embedded DownSave interface.
- Internet permission for supported catalogue/API searches.
- Android DownloadManager hand-off for direct downloadable files.
- App label and package: `DownSave` / `com.mileztech.downsave`.

## Important limitations
- This project does not bypass DRM, login requirements, privacy settings, or platform download restrictions.
- YouTube search requires a YouTube Data API v3 key; the API provides discovery/metadata, not a general media extractor.
- SoundCloud API access requires approved app credentials and OAuth.
- Facebook/TikTok are link-opening helpers, not media extractors.
- The embedded prototype's API and download functionality remains subject to each source's CORS, API, terms, and server behaviour.
- This generated project has not been compiled or tested on a physical Android device in this environment.

## Build an APK using Android Studio (free)
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Open this `DownSaveAndroid` folder in Android Studio.
3. Allow Android Studio to install the required Android SDK (compile SDK 35) and Gradle components.
4. Wait for Gradle Sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When complete, use **Build > Locate** to find the APK. It will normally be at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager/browser.

## App identity
- Name: DownSave
- Brand: Powered by Mileztech
- Application ID: com.mileztech.downsave
- Version: 1.0.0
